void main(List<String> args) {
  var num1 = 3;
  var num2 = 4;
  var oprators = "+";

  if (oprators == "+") {
    var result = num1 + num2;
    print(result);
  } else if (oprators == "-") {
    var result = num1 - num2;
    print(result);
  }
   else if (oprators == "*") {
    var result = num1 * num2;
    print(result);
  }
   else if (oprators == "/") {
    var result = num1 / num2;
    print(result);
  }
   else if (oprators == "%") {
    var result = num1 % num2;
    print(result);
  }
   else if (oprators == "-") {
    var result = num1 - num2;
    print(result);
  }
}
