void main() {
  String letter = "a";

  if (letter == 'a' ||
      letter == 'e' ||
      letter == 'i' ||
      letter == 'o' ||
      letter == 'u') {
    print("Letter $letter is a Vowel");
  } else {
    print("letter $letter is Consonant");
  }
}
