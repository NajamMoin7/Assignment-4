void main() {
  int number = 7;

  for (var i = 1; i < 16; i++) {
    var result = number * i;
    print("$number x $i = $result");
  }
}
