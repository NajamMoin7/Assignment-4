void main() {
  String word = "natsikaP nawaJ";

  print(word.split('').reversed.join());
}
