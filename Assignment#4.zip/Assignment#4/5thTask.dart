void main() {
  var fruits = ["apple", "banana", "mango", "orange", "strawberry"];
  for (var a in fruits) {
    print(a);
  }
}
